#include <iostream>
#include "SingletonClass.h"

void SingletonClass::doStuff()
{
    std::cout << "De singleton werkt";
}
