/*
 * All rights reserved (c) EI-Wiki 2020
 * This code is under GNU General Public License v3.0
 * More info at ei-wiki.uantwerpen.be/license
 */
#ifndef EIWIKI_SDLOBJECT_H
#define EIWIKI_SDLOBJECT_H

#include "AObject.h"

class SDLObject : public AObject
{
public:
    void doStuff() override;
};


#endif
